#define _ISOC99_SOURCE 1

#include <stdio.h>
#include <math.h>

int main()
{
   printf("%f\n", sin(0.12));
   printf("%f\n", cos(0.12));
   printf("%f\n", tan(0.12));
   printf("%f\n", asin(0.12));
   printf("%f\n", acos(0.12));
   printf("%f\n", atan(0.12));
   printf("%f\n", sinh(0.12));
   printf("%f\n", cosh(0.12));
   printf("%f\n", tanh(0.12));
   printf("%f\n", exp(0.12));
   printf("%f\n", fabs(-0.12));
   printf("%f\n", log(0.12));
   printf("%f\n", log10(0.12));
   printf("%f\n", pow(0.12, 0.12));
   printf("%f\n", sqrt(0.12));
   printf("%f\n", round(12.34));
   printf("%f\n", ceil(12.34));
   printf("%f\n", floor(12.34));
   printf("%f\n", rint(12.75));
   printf("%f\n", (double)rintf(12.75f));
   printf("%ld\n", lrint(12.75));
   printf("%lld\n", llrint(12.75));
   printf("%f\n", trunc(-12.75));
   printf("%f\n", (double)truncf(-12.75f));

   return 0;
}

/* vim: set expandtab ts=4 sw=3 sts=3 tw=80 :*/
